using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[ExecuteInEditMode]
public class GridSystem : EditorWindow
{
    [SerializeField] int gridSize;
    [SerializeField] int plotArea;
    static bool showGrid;
    static bool isWired;

    [MenuItem("Tools/Grid")]
    public static void Open()
    {
        GetWindow<GridSystem>();
    }
    public Transform gridRoot;

    public void OnGUI()
    {
        SerializedObject window = new SerializedObject(this);
        SerializedProperty property = window.FindProperty("gridRoot");
        EditorGUILayout.PropertyField(property);
        EditorGUILayout.LabelField("\n");
        if (gridRoot == null)
        {
            if (GUILayout.Button("\nCreat Root\n"))
            {
                gridRoot = new GameObject("Grid").GetComponent<Transform>();
                gridRoot.tag = "Grid";
            }
            if (Selection.activeGameObject != null && !Selection.activeGameObject.GetComponent<Waypoint>() && Selection.activeGameObject.tag == "Grid" && GUILayout.Button("\nAssign Selected\n"))
            {
                gridRoot = Selection.activeGameObject.transform;
            }
        }
        else
        {
            BuildWindow();
        }
    }
    void BuildWindow()
    {
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("Show Grid:");
        showGrid =  GUILayout.Toggle(showGrid, "\t\t\t\t\t\t\t\t\t\t\t\t");
        EditorGUILayout.EndHorizontal();

        if (showGrid)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Wired Grid:");
            isWired = GUILayout.Toggle(isWired, "\t\t\t\t\t\t\t\t\t\t\t\t");
            EditorGUILayout.EndHorizontal();
        }
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("Grid Size: ");
        gridSize = (int)EditorGUILayout.IntField(gridSize);
        EditorGUILayout.LabelField("    ");

        EditorGUILayout.LabelField("Plot Area: ");
        plotArea = (int)EditorGUILayout.IntField(plotArea);
        EditorGUILayout.EndHorizontal();

        if (GUILayout.Button("Build Grid"))
        {
            BuildGrid();
        }
    }

    // Update is called once per frame
    void BuildGrid()
    {
        foreach(Node plot in gridRoot.GetComponentsInChildren<Node>())
        {
            DestroyImmediate(plot.gameObject);
        }
        for (int x = 0; x < gridSize; x++)
        {
            for (int z = 0; z < gridSize; z++)
            {
                GameObject node = new GameObject("Node: (" + x * plotArea + ", " + z * plotArea + ")", typeof(Node));
                node.transform.localPosition = gridRoot.position + new Vector3(x * plotArea, 0, z * plotArea);
                node.transform.parent = gridRoot.transform;
                node.GetComponent<Node>().area = plotArea;
                node.AddComponent<BoxCollider>().size = new Vector3(1, 0.1f, 1) * plotArea;
            }
        }
    }

    [DrawGizmo(GizmoType.NonSelected | GizmoType.Selected | GizmoType.Pickable)]
    public static void OnDrawSceneGizmo(Node node, GizmoType gizmoType)
    {
        if(showGrid)
        {
            if (isWired)
            {
                Gizmos.DrawWireCube(node.transform.position, new Vector3(node.area - 0.2f, 0.2f, node.area - 0.2f));
            }
            else
            {
                Gizmos.DrawCube(node.transform.position, new Vector3(node.area - 0.2f, 0.2f, node.area - 0.2f));
            }
            Gizmos.DrawSphere(node.transform.position, 0.25f);
        }
    }
}
