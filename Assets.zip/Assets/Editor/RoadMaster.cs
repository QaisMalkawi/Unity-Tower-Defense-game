using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class RoadMaster : EditorWindow
{
    [MenuItem("Tools/AI/Path")]
    public static void Open()
    {
        GetWindow<RoadMaster>();
    }
    public Transform waypointRoot;

    public void OnGUI()
    {
        SerializedObject window = new SerializedObject(this);
        SerializedProperty property = window.FindProperty("waypointRoot");
        EditorGUILayout.PropertyField(property);
        EditorGUILayout.LabelField("\n");
        if (waypointRoot == null)
        {
            if (GUILayout.Button("\nCreat Root\n"))
            {
                waypointRoot = new GameObject("New Road System").GetComponent<Transform>();
                waypointRoot.tag = "Path";
            }
            if (Selection.activeGameObject != null && !Selection.activeGameObject.GetComponent<Waypoint>() && Selection.activeGameObject.tag == "Path" && GUILayout.Button("\nAssign Selected\n"))
            {
                waypointRoot = Selection.activeGameObject.transform;
            }
        }
        else
        {
            PopulateWindow();
        }
        if (Selection.activeGameObject != null && Selection.activeGameObject.GetComponent<Waypoint>())
        {
            Debug.Log(Selection.activeGameObject.GetComponent<Waypoint>());
        }
    }
    public void PopulateWindow()
    {
        EditorGUILayout.LabelField("Manager:");
        if (waypointRoot.childCount == 0)
        {
            if (GUILayout.Button("Start System"))
            {
                CreateWaypoint();
            }
        }
        if (Selection.activeGameObject != null && Selection.activeGameObject.GetComponent<Waypoint>())
        {
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Create Waypoint Before"))
            {
                CreateWaypointBefore();
            }
            if (Selection.activeGameObject != null && Selection.activeGameObject.GetComponent<Waypoint>().nextWayPoint != null && GUILayout.Button("Create Branch"))
            {
                CreateBranch();
            }
            if (GUILayout.Button("Create Waypoint After"))
            {
                CreateWaypointAfter();
            }
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label("");
            if (GUILayout.Button("Remove Waypoint"))
            {
                RemoveWaypoint();
            }
            GUILayout.Label("");
            EditorGUILayout.EndHorizontal();
        }
        else
        {
            if (waypointRoot.childCount != 0)
            {
                GUILayout.Label("Select a Waypoint to Start Editing");
                if (GUILayout.Button("Select Waypoint"))
                {
                    Selection.activeGameObject = waypointRoot.GetChild(Random.Range(0, waypointRoot.childCount)).gameObject;
                }
            }
        }

        if(GUILayout.Button("Finish Editing"))
        {
            waypointRoot = null;
        }
    }

    public void CreateWaypoint()
    {
        GameObject newWaypoint = new GameObject("Waypoint " + waypointRoot.childCount, typeof(Waypoint));
        newWaypoint.transform.SetParent(waypointRoot);

        Waypoint waypoint = newWaypoint.GetComponent<Waypoint>();

        waypoint.transform.position = waypointRoot.position;

        Selection.activeGameObject = newWaypoint.gameObject;
    }

    public void CreateWaypointBefore()
    {
        GameObject waypoint = new GameObject("Waypoint " + waypointRoot.childCount, typeof(Waypoint));
        waypoint.transform.SetParent(waypointRoot, false);

        Waypoint newWaypoint = waypoint.GetComponent<Waypoint>();

        Waypoint selectedWaypoint = Selection.activeGameObject.GetComponent<Waypoint>();

        newWaypoint.transform.position = selectedWaypoint.transform.position;

        if (selectedWaypoint.previousWayPoint != null)
        {
            newWaypoint.previousWayPoint = selectedWaypoint.previousWayPoint;
            selectedWaypoint.previousWayPoint.nextWayPoint = newWaypoint;
            newWaypoint.transform.position = (selectedWaypoint.transform.position + selectedWaypoint.previousWayPoint.transform.position) / 2;
        }
        newWaypoint.nextWayPoint = selectedWaypoint;
        selectedWaypoint.previousWayPoint = newWaypoint;
        newWaypoint.transform.SetSiblingIndex(selectedWaypoint.transform.GetSiblingIndex());
        Selection.activeGameObject = waypoint;
    }
    public void CreateWaypointAfter()
    {
        GameObject waypoint = new GameObject("Waypoint " + waypointRoot.childCount, typeof(Waypoint));
        waypoint.transform.SetParent(waypointRoot, false);

        Waypoint newWaypoint = waypoint.GetComponent<Waypoint>();

        Waypoint selectedWaypoint = Selection.activeGameObject.GetComponent<Waypoint>();

        newWaypoint.transform.position = selectedWaypoint.transform.position;

        newWaypoint.previousWayPoint = selectedWaypoint;

        if (selectedWaypoint.nextWayPoint != null)
        {
            selectedWaypoint.nextWayPoint.previousWayPoint = newWaypoint;
            newWaypoint.nextWayPoint = selectedWaypoint.nextWayPoint;
            newWaypoint.transform.position = (selectedWaypoint.transform.position + selectedWaypoint.nextWayPoint.transform.position) / 2;
        }
        selectedWaypoint.nextWayPoint = newWaypoint;
        newWaypoint.transform.SetSiblingIndex(selectedWaypoint.transform.GetSiblingIndex());
        Selection.activeGameObject = waypoint;
    }
    public void RemoveWaypoint()
    {
        Waypoint selectedWaypoint = Selection.activeGameObject.GetComponent<Waypoint>();
        if (selectedWaypoint.previousWayPoint != null)
        {
            selectedWaypoint.previousWayPoint.nextWayPoint = selectedWaypoint.nextWayPoint;
            Selection.activeGameObject = selectedWaypoint.previousWayPoint.gameObject;
        }
        if (selectedWaypoint.nextWayPoint != null)
        {
            selectedWaypoint.nextWayPoint.previousWayPoint = selectedWaypoint.previousWayPoint;
            Selection.activeGameObject = selectedWaypoint.nextWayPoint.gameObject;
        }
        DestroyImmediate(selectedWaypoint.gameObject);
    }
    public void CreateBranch()
    {
        GameObject waypointob = new GameObject("Waypoint " + waypointRoot.childCount);
        waypointob.AddComponent<Waypoint>();
        waypointob.transform.SetParent(waypointRoot, false);

        Waypoint newWaypoint = waypointob.GetComponent<Waypoint>();

        Waypoint branchedFrom = Selection.activeGameObject.GetComponent<Waypoint>();
        Debug.Log(newWaypoint);
        branchedFrom.GetComponent<Waypoint>().branches.Add(newWaypoint);

        newWaypoint.transform.position = (branchedFrom.transform.position + branchedFrom.nextWayPoint.transform.position) / 2f;

        Selection.activeGameObject = waypointob;
    }
}
