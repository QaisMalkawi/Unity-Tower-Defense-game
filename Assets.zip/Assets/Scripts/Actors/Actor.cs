using UnityEngine;

public class Actor : MonoBehaviour
{
    public int cost;
    public int returnValue;
    public Mesh iconMesh;
    public Node node;
    public Upgrade[] upgrades;
    int currentUpgrade;
    public bool hasUpgrades;

    public void Sell()
    {
        node.isOccubied = false;
        node.actor = null;
        Destroy(gameObject);
    }
    public void Upgrade()
    {
        if (currentUpgrade < upgrades.Length)
        {
            Upgrade upgrade = upgrades[currentUpgrade];
            returnValue = upgrade.returnValue;
            if (GetComponent<LaserBeamer>())
            {
                //is laser
                LaserBeamer laser = GetComponent<LaserBeamer>();
                laser.range = upgrade.range;
                laser.dps = upgrade.dps;
            }
            else if(GetComponent<Launcher>())
            {
                //is Launcher
                Launcher laser = GetComponent<Launcher>();
                laser.range = upgrade.range;
                laser.dps = upgrade.dps;
                laser.fireRate = upgrade.fireRate;
            }
            currentUpgrade++;
            if (currentUpgrade >= upgrades.Length)
            {
                hasUpgrades = false;
            }
        }
    }

    public int nextUpgradeCost()
    {
        if(hasUpgrades)
        {
            return upgrades[currentUpgrade].cost;
        }
        return -1;
    }
}

[System.Serializable]
public class Upgrade
{
    public int cost;
    public float fireRate;
    public float range;
    public float dps;
    public int returnValue;
}
