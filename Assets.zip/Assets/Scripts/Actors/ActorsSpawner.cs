using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ActorsSpawner : MonoBehaviour
{


    public Actor[] actors;
    public Sprite[] actorPreview;

    [HideInInspector] public int money;
    [HideInInspector] public int index;
    [HideInInspector] public bool canPlace;
    [HideInInspector] public bool isEditing;
    [HideInInspector] public Actor actorSelected;
    [HideInInspector] public GameObject guide;

    [SerializeField] Obstacle[] obstacles;
    [SerializeField] float obstaclesSpawningInterval;
    [SerializeField] int startMoney;

    public GameObject editingUI;
    public TMP_Text sellText;
    public TMP_Text upgradeText;

    public Image actorPreviewField;
    public TMP_Text actorNameField;

    

    private void Awake()
    {
        money = startMoney;
        canPlace = true;
        guide = GameObject.Find("Guide");
        InvokeRepeating("SpawnObstacle", obstaclesSpawningInterval, obstaclesSpawningInterval);
    }
    void Update()
    {
        UpdateEditingUI();
        UpdateActorsUI();
    }
    public int getUpgradeCost(Actor actor)
    {
        return actor.nextUpgradeCost();
    }

    public int getSellPrice(Actor actor)
    {
        return actor.returnValue;
    }

    public void sellActor()
    {
        if (actorSelected.GetComponent<Obstacle>())
        {
            Obstacle obstacle = actorSelected.GetComponent<Obstacle>();
            obstacle.isDesolving = true;
            actorSelected.node.isUsable = false;
            obstacle.Invoke("Remove", obstacle.removingTime);
            actorSelected.node.isOccubied = false;
            actorSelected.node.actor = null;
            actorSelected = null;
            isEditing = false;
            FindObjectOfType<Tower>().UpdateUI();
            return;
        }
        money += getSellPrice(actorSelected);
        actorSelected.Sell();
        FindObjectOfType<Tower>().UpdateUI();
        actorSelected = null;
        isEditing = false;
    }

    public void upgradeActor()
    {
        if (money >= getUpgradeCost(actorSelected))
        {
            money -= getUpgradeCost(actorSelected);
            actorSelected.Upgrade();
        }
        actorSelected = null;
        isEditing = false;
        FindObjectOfType<Tower>().UpdateUI();
    }

    void UpdateEditingUI()
    {
        editingUI.SetActive(isEditing);
        if(isEditing)
        {
            sellText.text = "Sell: " + getSellPrice(actorSelected);
            float upgradePrice = getUpgradeCost(actorSelected);
            if (upgradePrice <= -1)
            {
                upgradeText.text = "No Upgrades";
            }
            else
            {
                upgradeText.text = "Upgrade: " + getUpgradeCost(actorSelected);
            }
        }
    }

    public void SetCanPlace(bool state)
    {
        canPlace = state;
        UpdateActorsUI();
    }
    public void toggleCanPlace()
    {
        canPlace = !canPlace;
        UpdateActorsUI();
    }
    public void AddtoActorIndex(int value)
    {
        index = Mathf.Clamp(index + value, 0, actors.Length - 1);
        UpdateActorsUI();
    }
    void UpdateActorsUI()
    {
        actorPreviewField.sprite = actorPreview[index];
        actorNameField.text = actors[index].name + "\n" + actors[index].cost + "$";
    }

    void SpawnObstacle()
    {
        Node[] avilableNodes = FindObjectsOfType<Node>();
        Node node = avilableNodes[Random.Range(0, avilableNodes.Length)];
        if (node.isOccubied || !node.isUsable)
            return;
        Obstacle obs = Instantiate(obstacles[Random.Range(0, obstacles.Length)], node.transform.position, Quaternion.identity);
        node.actor = obs.GetComponent<Actor>();
        node.actor.node = node;
        node.isOccubied = true;
    }
}
