using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserBeamer : MonoBehaviour
{
    public Transform head;
    public LineRenderer laser;
    public Transform muzzle;

    [Tooltip("Range in Tiles.")]public float range;
    public float dps;
    public AudioClip lockSound;
    public AudioClip shootSound;

    AudioSource laserSound;

    EnemyAI target;

    private void Start()
    {
        InvokeRepeating("UpdateActor", 1, 0.5f);
        laserSound = GetComponent<AudioSource>();
    }

    void UpdateActor()
    {
        EnemyAI[] enemies = GameObject.FindObjectsOfType<EnemyAI>();
        float shortestDistance = Mathf.Infinity;
        EnemyAI nearestEnemy = null;
        foreach (EnemyAI enemy in enemies)
        {
            float distance = Vector3.Distance(transform.position, enemy.transform.position);
            if (distance < shortestDistance)
            {
                shortestDistance = distance;
                nearestEnemy = enemy;
            }
        }
        if (enemies != null && shortestDistance <= (range * FindObjectOfType<Node>().area))
        {
            if (target != null)
            {
                if (target.GetInstanceID() != nearestEnemy.GetInstanceID())
                {
                    AudioController.PlayAudio(lockSound, transform.position, 1);
                }
            }
            else
            {
                AudioController.PlayAudio(lockSound, transform.position, 1);
            }
            target = nearestEnemy;
            laserSound.clip = shootSound;
            laserSound.Play();
        }
        else
        {
            target = null;
            laserSound.Stop();
        }
    }
    private void Update()
    {
        if (target != null)
        {

            head.LookAt(target.transform.position);
            target.Damage(dps * Time.deltaTime);
            Vector3[] pos = new Vector3[2]
            {
                    muzzle.position,
                    target.transform.position
            };
            laser.SetPositions(pos);
        }
        else
        {
            Vector3[] pos = new Vector3[2]
            {
                    muzzle.position,
                    muzzle.position
            };
            laser.SetPositions(pos);
        }
    }
}
