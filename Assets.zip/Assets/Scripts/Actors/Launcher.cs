using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Launcher : MonoBehaviour
{
    public Transform head;
    public Transform muzzle;
    public Transform projectile;

    [Tooltip("Range in Tiles.")] public float range;
    public float fireRate;
    public float dps;
    public float bulletVelocity;
    EnemyAI target;
    float coolDown;
    [SerializeField] AudioClip shootSound;
    [SerializeField, Range(0.0f, 1.0f)] float volume;

    private void Start()
    {
        InvokeRepeating("UpdateActor", 1, 0.5f);
    }

    void UpdateActor()
    {
        EnemyAI[] enemies = GameObject.FindObjectsOfType<EnemyAI>();
        float shortestDistance = Mathf.Infinity;
        EnemyAI nearestEnemy = null;
        foreach (EnemyAI enemy in enemies)
        {
            float distance = Vector3.Distance(transform.position, enemy.transform.position);
            if (distance < shortestDistance)
            {
                shortestDistance = distance;
                nearestEnemy = enemy;
            }
        }
        if (enemies != null && shortestDistance <= (range * FindObjectOfType<Node>().area))
        {
            target = nearestEnemy;
        }
        else
        {
            target = null;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(target != null)
        {
            head.LookAt(target.transform.position);
            if(coolDown <= 0)
            {
                coolDown = 1 / fireRate;
                Shoot();
            }
            else{
                coolDown -= Time.deltaTime;
            }
        }
    }

    void Shoot()
    {
        Projectile bullet = Instantiate(projectile.gameObject, muzzle.position, Quaternion.identity).GetComponent<Projectile>();
        bullet.target = target;
        bullet.speed = bulletVelocity;
        bullet.damage = dps;
        AudioController.PlayAudio(shootSound, transform.position, 2, volume);
    }
}
