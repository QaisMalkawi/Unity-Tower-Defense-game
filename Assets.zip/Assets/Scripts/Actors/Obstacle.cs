using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacle : MonoBehaviour
{
    Actor selfActor;
    public float removingTime;
    public float heightLimitsTop = 7;
    public float heightLimitsDown = 7;
    float progress;
    [HideInInspector] public bool isDesolving;
    void Awake()
    {
        selfActor = this.GetComponent<Actor>();
        progress = heightLimitsTop;
    }

    private void Update()
    {
        if (isDesolving)
            progress = Mathf.Lerp(progress, heightLimitsDown, Time.deltaTime / (removingTime - 1));
            GetComponent<MeshRenderer>().material.SetFloat("_CutoffHeight", progress);
    }

    public void Remove()
    {
        FindObjectOfType<ActorsSpawner>().money += selfActor.returnValue;
        FindObjectOfType<Tower>().UpdateUI();
        this.GetComponent<Actor>().node.isUsable = true;
        Destroy(this.gameObject);
    }
}
