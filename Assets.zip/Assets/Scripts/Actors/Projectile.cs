using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    public GameObject particles;
    [HideInInspector]public EnemyAI target;
    [HideInInspector]public float speed;
    public float damage;
    [SerializeField] bool hasEffect;
    [SerializeField] AreaOfEffect effect;
    public AudioClip impactSound;

    void Update()
    {
        if (target != null)
        {
            if (Vector3.Distance(transform.position, target.transform.position) > 1)
            {
                Vector3 dir = (target.transform.position - transform.position).normalized;
                transform.Translate(dir * speed * Time.fixedDeltaTime, Space.World);
                transform.LookAt(target.transform.position);
            }
            else
            {
                target.Damage(damage);
                Explode();
            }
        }
        else
        {
            Explode();
        }
    }

    void Explode() 
    {
        if(hasEffect)
        {
            Instantiate(effect, transform.position, Quaternion.identity);
        }
        if (impactSound != null)
        {
            AudioController.PlayAudio(impactSound, transform.position, 2);
        }
        particles.SetActive(true);
        gameObject.GetComponent<MeshFilter>().sharedMesh = null;
        Destroy(gameObject, 1.25f);
        this.GetComponent<Projectile>().enabled = false;
        this.GetComponent<TrailRenderer>().enabled = false;
    }
}
