using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AreaOfEffect : MonoBehaviour
{
    [SerializeField] float targetSpeed;
    [SerializeField] float targetResistance;
    [SerializeField] float dps;
    [SerializeField, Tooltip("The effect area in Tiles")] float areaOfEffect;
    float aoe;
    [SerializeField] int time;
    EnemyAI[] enemies;

    void Start()
    {
        aoe = areaOfEffect * FindObjectOfType<Node>().area;
        InvokeRepeating("ApplyEffect", 0, 1);
        InvokeRepeating("ClearEffect", 0.99f, 1);
        Destroy(gameObject, time);
    }

    void ApplyEffect()
    {
        enemies = DetectEnemies();
        foreach (EnemyAI enemy in enemies)
        {
            enemy.resistanceModifier = targetResistance;
            enemy.speedModifier = targetSpeed;
            enemy.Damage(dps);
        }
    }

    void ClearEffect()
    {
        foreach (EnemyAI enemy in enemies)
        {
            enemy.resistanceModifier = 1;
            enemy.speedModifier = 1;
        }
    }
    EnemyAI[] DetectEnemies()
    {
        EnemyAI[] _enemies = GameObject.FindObjectsOfType<EnemyAI>();
        List<EnemyAI> selectedEnemies = new List<EnemyAI>();
        foreach (EnemyAI enemy in _enemies)
        {
            float distance = Vector3.Distance(transform.position, enemy.transform.position);
            if (distance <= aoe)
            {
                selectedEnemies.Add(enemy);
            }
        }
        return selectedEnemies.ToArray();
    }
}
