using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class AudioController
{
    public static void PlayAudio(AudioClip clip, Vector3 position, float lifeDuration = 5, float volume = 1)
    {
        GameObject sourceGO = new GameObject(" ", typeof(AudioSource));
        sourceGO.transform.position = position;
        AudioSource source = sourceGO.GetComponent<AudioSource>();
        source.clip = clip;
        source.volume = volume;
        source.Play();
        GameObject.Destroy(source.gameObject, lifeDuration);
    }
}
