using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    [SerializeField] Rect CameraRect;
    [SerializeField] float sensitivity;
    float movementDelta;
    public float toggleMovingMagnitude;
    public bool moving;

    Vector3 holdPoint;

    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
            holdPoint = Input.mousePosition;
        }
        if(Input.GetMouseButton(0))
        {
            transform.position = transform.position + new Vector3(holdPoint.x - Input.mousePosition.x, 0, holdPoint.y - Input.mousePosition.y) * Time.deltaTime * sensitivity;

            transform.position = new Vector3(Mathf.Clamp(transform.position.x, CameraRect.x, CameraRect.width), 0, Mathf.Clamp(transform.position.z, CameraRect.y, CameraRect.height));

            movementDelta = Vector3.Distance(holdPoint, Input.mousePosition);
            if(movementDelta >= toggleMovingMagnitude)
            {
                moving = true;
            }
            holdPoint = Input.mousePosition;
        }
        if(Input.GetMouseButtonUp(0))
        {
            movementDelta = 0;
            moving = false;
        }
    }
}
