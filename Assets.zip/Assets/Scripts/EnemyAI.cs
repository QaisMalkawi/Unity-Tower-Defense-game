using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyAI : MonoBehaviour
{
    [SerializeField] float speed;
    [SerializeField] int damage;
    [SerializeField] float health;
    [SerializeField] Slider healthSlider;
    [SerializeField] int killScore;
    [SerializeField] int moneyReward;
    [HideInInspector] public Waypoint waypoint;
    [HideInInspector] public float resistanceModifier = 1;
    [HideInInspector] public float speedModifier = 1;


    void Start()
    {
        healthSlider.maxValue = health;
        healthSlider.value = health;
    }
    private void Update()
    {
        if (Vector3.Distance(transform.position, waypoint.GetPosition()) >= 0.5)
        {
            Vector3 dir = waypoint.GetPosition() - transform.position;
            transform.Translate(dir.normalized * speed * Time.deltaTime * speedModifier, Space.World);
        }
        else
        {
            waypoint = FindNextWaypoint();
        }
    }

    Waypoint FindNextWaypoint()
    {
        Waypoint wp = waypoint.nextWayPoint;
        if (wp == null)
        {
            ReachedTower();
            return null;
        }
        else
        {
            return wp;
        }
    }

    void ReachedTower()
    {
        Destroy(gameObject);
        if (GameObject.FindObjectOfType<Tower>() != null)
        {
            GameObject.FindObjectOfType<Tower>().Damage(damage);
            GameObject.FindObjectOfType<Tower>().score -= (int)killScore / 2;
        }
    }

    public void Damage(float damage)
    {
        health -= (damage / resistanceModifier);
        healthSlider.value = health;
        if (health <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        Destroy(gameObject);
        FindObjectOfType<Tower>().score += killScore;
        FindObjectOfType<ActorsSpawner>().money += moneyReward;
        FindObjectOfType<Tower>().UpdateUI();
    }
}
