using UnityEngine;
using UnityEngine.UI;
using System.IO;


public class IconMaker : MonoBehaviour
{
    public GameObject item;
    public Camera captureCamera;
    public Image icon;
    public float safeZone = 0.1f;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
            icon.sprite = CaptureIcon();
            
    }

    Sprite CaptureIcon()
    {

        captureCamera.orthographicSize = item.GetComponent<Renderer>().bounds.extents.y + safeZone;
        int resX = captureCamera.pixelWidth;
        int resY = captureCamera.pixelHeight;

        int clipX = 0;
        int clipY = 0;

        if (resX > resY)
            clipX = resX - resY;
        else if (resY > resX)
            clipY = resY - resX;

        Texture2D tex = new Texture2D(resX - clipX, resY - clipY, TextureFormat.RGBA32, false);
        RenderTexture rt = new RenderTexture(resX, resY, 24);
        captureCamera.targetTexture = rt;
        RenderTexture.active = rt;

        captureCamera.Render();
        tex.ReadPixels(new Rect(clipX / 2, clipY / 2, resX - clipX, resY - clipY),0, 0);
        tex.Apply();
        byte[] bytes = tex.EncodeToPNG();

        captureCamera.targetTexture = null;
        RenderTexture.active = null;
        Destroy(rt);

        Sprite sp = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(tex.width / 2, tex.height / 2));
        File.WriteAllBytes(Application.dataPath + "/../Assets/Textures/Icons/9Icon.png".Replace("9", item.transform.root.name), bytes);
        return sp;
    }
}
