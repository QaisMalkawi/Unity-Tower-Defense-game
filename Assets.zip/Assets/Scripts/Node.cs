using UnityEngine;
using UnityEngine.UI;

public class Node : MonoBehaviour
{
    public int area;
    public bool isOccubied;
    public bool isUsable;
    ActorsSpawner spawner;
    public Actor actor;

    private void Start()
    {
        if(spawner == null)
            spawner = FindObjectOfType<ActorsSpawner>();
        else
            spawner.guide.transform.position = Vector3.up * -3;

        isUsable = true;
    }

    private void OnMouseEnter()
    {
        if (!isUsable)
            return;
        GameObject guide = spawner.guide;
        guide.GetComponent<MeshFilter>().sharedMesh = spawner.actors[spawner.index].iconMesh;
        guide.transform.position = transform.position + ((spawner.isEditing || isOccubied) ? Vector3.up * -5 : Vector3.up * 3);
    }
    private void OnMouseExit()
    {
        spawner.guide.transform.position = transform.position +  Vector3.up * -5;
    }
    private void OnMouseUpAsButton()
    {
        if (!isUsable)
            return;
        if (Input.mousePosition.x > Screen.currentResolution.width - 300 && Input.mousePosition.z < 120)
            return;
        if (isOccubied)
        {
            if (spawner.isEditing)
            {
                if (spawner.actorSelected.GetInstanceID() == actor.GetInstanceID())
                {
                    spawner.isEditing = false;
                    spawner.actorSelected = null;
                }
                else
                {
                    spawner.isEditing = true;
                    spawner.actorSelected = actor;
                }
            }
            else
            {
                spawner.isEditing = true;
                spawner.actorSelected = actor;
            }
        }
        else
        {
            if (spawner.isEditing || !spawner.canPlace || FindObjectOfType<CameraController>().moving)
                return;
            spawner.isEditing = false;
            spawner.actorSelected = null;
            if (spawner.actors[spawner.index].cost <= spawner.money)
            {
                spawner.money -= spawner.actors[spawner.index].cost;
                actor = Instantiate(spawner.actors[spawner.index], transform.position, Quaternion.identity);
                actor.node = this;
                isOccubied = true;
                this.OnMouseEnter();
                FindObjectOfType<Tower>().UpdateUI();
            }
        }
    }
}
