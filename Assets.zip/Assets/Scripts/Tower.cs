using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Tower : MonoBehaviour
{
    public int score;
    public int health;


    [SerializeField] Slider healthBar;
    [SerializeField] TMP_Text moneyField;
    [SerializeField] TMP_Text scoreField;

    void Start()
    {
        healthBar.maxValue = health;
        healthBar.value = health;
        UpdateUI();
    }

    public void Damage(int damage)
    {
        health -= damage;
        UpdateUI();
        if (health <= 0)
        {
            FindObjectOfType<WaveSpawner>().roundDone(false);
            Destruction();
        }
    }

    void Destruction()
    {
        Destroy(gameObject);
    }

    public void UpdateUI()
    {
        healthBar.value = health;
        moneyField.text = "Cash: " + FindObjectOfType<ActorsSpawner>().money;
        scoreField.text = "Score: " + score;
    }
}
