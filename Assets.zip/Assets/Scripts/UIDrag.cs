using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIDrag : MonoBehaviour
{
    [SerializeField] RectTransform body;
    float elTarget;
    bool isOpen;
    [SerializeField] float dragSpeed;
    [SerializeField] float upHeight;
    [SerializeField] float downHeight;

    public void toggleStat()
    {
        isOpen = !isOpen;
    }

    private void Update()
    {
        elTarget = isOpen ? upHeight : downHeight;
        /*if (Mathf.Abs(invTarget - body.position.y) > 1)
        {
            body.position = body.position + (dir * Vector3.up * dragSpeed * Time.deltaTime);
        }*/
        body.position = Vector2.Lerp(new Vector2(body.position.x, body.position.y), new Vector2(body.position.x, elTarget), dragSpeed * Time.deltaTime);
    }

}
