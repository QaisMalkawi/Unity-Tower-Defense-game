using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;

public class WaveSpawner : MonoBehaviour
{
    float wavesCooldown;
    float countDown = 0.25f;

    int currentWave = -1;

    bool waveActive;
    bool Spawningwave;

    [Header("")]
    [SerializeField] Wave[] waves;

    [Header("")]
    [SerializeField] GameObject levelDoneUI;
    [SerializeField] GameObject levelWonUI;
    [SerializeField] GameObject levelLostUI;

    private void Update()
    {
        if (!waveActive && currentWave != waves.Length - 1)
        {
            if (countDown <= 0)
            {
                waveActive = true;
                Spawningwave = true;
                StartCoroutine(SpawnWave());
            }
            else
            {
                countDown -= Time.deltaTime;
            }
        }
        if(!Spawningwave)
        {
            if (GameObject.FindObjectsOfType<EnemyAI>().Length == 0)
            {
                waveActive = false;
            }
        }
        if(currentWave == waves.Length - 1)
        {
            roundDone(true);
        }
    }

    public void roundDone(bool hasWon)
    {
        levelDoneUI.SetActive(true);
        StartCoroutine("slowTime");
        FindObjectOfType<ActorsSpawner>().SetCanPlace(false);
        if(hasWon)
        {
            levelWonUI.SetActive(true);
            Debug.Log("you won :)");
        }
        else
        {
            levelLostUI.SetActive(true);
            Debug.Log("you lost :(");
        }
    }
    IEnumerator slowTime()
    {
        while (Time.timeScale > 0.002f)
        {
            Time.timeScale = Mathf.Lerp(Time.timeScale, 0, 0.05f);
            yield return new WaitForSeconds(0.001f);
        }
        Time.timeScale = 0;
        yield break;
    }
    IEnumerator SpawnWave()
    {
        currentWave++;
        for (int k = 0; k < waves[currentWave].enemies.Length; k++)
        {
            yield return new WaitForSeconds(waves[currentWave].enemies[k].typeCooldown);
            for (int e = 0; e < waves[currentWave].enemies[k].count; e++)
            {
                yield return new WaitForSeconds(waves[currentWave].enemies[k].readyTime);
                SpawnEnemy(waves[currentWave].enemies[k].enemy);
            }
        }
        Spawningwave = false;
        wavesCooldown = waves[currentWave].waveCoolDown;
        countDown = wavesCooldown;
    }

    void SpawnEnemy(EnemyAI enemyType)
    {
        EnemyAI _enemy = Instantiate(enemyType, transform.position, Quaternion.identity);
        _enemy.waypoint = GameObject.Find("Waypoint 0").GetComponent<Waypoint>();
    }

    [System.Serializable]
    public struct Wave
    {
        public string waveTag;
        public WaveEnemy[] enemies;
        public float waveCoolDown;
    }
    [System.Serializable]
    public struct WaveEnemy
    {
        public float typeCooldown;
        public EnemyAI enemy;
        public float readyTime;
        public float count;
    }
}
